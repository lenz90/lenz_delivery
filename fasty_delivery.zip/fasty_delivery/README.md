# fasty_delivery

A new Flutter application.

## Getting Started

* Get an API key here: https://cloud.google.com/maps-platform/
* Edit android/app/src/main/AndroidManifest.xml and set the API KEY
* Edit lib/DirectionProvider and set the API KEY

Whatch the video at: https://www.youtube.com/watch?v=OlYqdC6pGRs
